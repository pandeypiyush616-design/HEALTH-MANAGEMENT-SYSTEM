# CareConnect - Online Healthcare Management System

MERN app with three roles (Admin, Doctor, Patient) and two AI features (symptom checker, patient history summary).

## 1. Install these (links)
- Node.js (LTS): https://nodejs.org
- VS Code: https://code.visualstudio.com
- Git: https://git-scm.com/downloads
- MongoDB Atlas (free database): https://www.mongodb.com/cloud/atlas/register
- Postman (API testing): https://www.postman.com/downloads
- Claude API key (for AI features): https://console.anthropic.com

## 2. Create the free database
1. Sign up at MongoDB Atlas, create a free M0 cluster.
2. Database Access: add a user with a password.
3. Network Access: add IP `0.0.0.0/0` (fine for learning; restrict later).
4. Click Connect > Drivers and copy the connection string.

## 3. Run the backend
```
cd backend
npm install
cp .env.example .env      # on Windows: copy .env.example .env
```
Edit `.env`: paste your MONGO_URI, set a long random JWT_SECRET, add ANTHROPIC_API_KEY.
```
npm run seed              # creates test users (once)
npm run dev               # http://localhost:5000
```

## 4. Run the frontend
```
cd frontend
npm install
npm run dev               # http://localhost:5173
```

## 5. Test logins (created by seed)
| Role | Email | Password |
|---|---|---|
| Admin | admin@clinic.com | admin123 |
| Doctor | asha@clinic.com | doctor123 |
| Patient | patient@clinic.com | patient123 |

Flow to try: patient books > doctor confirms and completes > doctor adds record > patient views history and rates the visit > admin sees analytics.

## 6. Deploy (free tiers)
- Backend: https://render.com (Web Service, root `backend`, build `npm install`, start `npm start`, add the .env values as environment variables; set CLIENT_URL to your frontend URL)
- Frontend: https://vercel.com (root `frontend`, add `VITE_API_URL=https://<your-backend>.onrender.com/api`)
- Database: already on Atlas

## 7. Change the password of the seeded admin before deploying.

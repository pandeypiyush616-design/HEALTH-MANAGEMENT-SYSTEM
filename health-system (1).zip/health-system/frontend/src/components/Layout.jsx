import { useState } from 'react';
import { useAuth } from '../AuthContext';

// Small toast hook: const [show, toast] = useToast();  show('Saved'); show('Oops','err'); render {toast}
export function useToast() {
  const [t, setT] = useState(null);
  const show = (text, type = 'ok') => { setT({ text, type }); setTimeout(() => setT(null), 3500); };
  return [show, t && <div className={`toast ${t.type}`} role="status">{t.text}</div>];
}

export const StatusBadge = ({ status }) => <span className={`badge ${status}`}>{status}</span>;

export default function Layout({ title, tabs, tab, setTab, children }) {
  const { user, logout } = useAuth();
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">CareConnect</div>
        <nav>
          {tabs.map((t) => (
            <button key={t} className={t === tab ? 'nav active' : 'nav'} onClick={() => setTab(t)}>{t}</button>
          ))}
        </nav>
        <div className="who">
          <div>{user.name}</div>
          <small>{user.role}</small>
          <button className="ghost" onClick={logout}>Log out</button>
        </div>
      </aside>
      <main className="main">
        <h1>{title}</h1>
        {children}
      </main>
    </div>
  );
}

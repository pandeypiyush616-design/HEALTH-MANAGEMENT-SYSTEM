import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import api, { errMsg } from '../api';
import Layout, { useToast, StatusBadge } from '../components/Layout';

const TABS = ['User Management', 'Appointments', 'System Settings', 'Analytics'];
const blank = { name: '', email: '', password: '', role: 'doctor', specialization: '', phone: '' };

export default function AdminDashboard() {
  const [tab, setTab] = useState(TABS[0]);
  const [show, toast] = useToast();
  return (
    <Layout title={tab} tabs={TABS} tab={tab} setTab={setTab}>
      {toast}
      {tab === TABS[0] && <Users show={show} />}
      {tab === TABS[1] && <Appointments show={show} />}
      {tab === TABS[2] && <Settings show={show} />}
      {tab === TABS[3] && <Analytics />}
    </Layout>
  );
}

function Users({ show }) {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const load = () => api.get('/admin/users').then((r) => setUsers(r.data)).catch((e) => show(errMsg(e), 'err'));
  useEffect(() => { load(); }, []);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = editId ? await api.put(`/admin/users/${editId}`, form) : await api.post('/admin/users', form);
      show(res.data.message);
      setForm(blank); setEditId(null); load();
    } catch (x) { show(errMsg(x), 'err'); }
  };
  const edit = (u) => { setEditId(u._id); setForm({ ...blank, ...u, password: '' }); window.scrollTo(0, 0); };
  const remove = async (u) => {
    if (!confirm(`Delete ${u.name}?`)) return;
    try { show((await api.delete(`/admin/users/${u._id}`)).data.message); load(); } catch (x) { show(errMsg(x), 'err'); }
  };

  return (
    <>
      <form className="card grid" onSubmit={submit}>
        <label>Name<input required value={form.name} onChange={set('name')} /></label>
        <label>Email<input type="email" required value={form.email} onChange={set('email')} /></label>
        <label>{editId ? 'New password (optional)' : 'Password'}<input type="password" minLength={6} required={!editId} value={form.password} onChange={set('password')} /></label>
        <label>Role
          <select value={form.role} onChange={set('role')}>
            <option>doctor</option><option>patient</option><option>admin</option>
          </select>
        </label>
        {form.role === 'doctor' && <label>Specialization<input value={form.specialization} onChange={set('specialization')} placeholder="e.g. Cardiologist" /></label>}
        <label>Phone<input value={form.phone} onChange={set('phone')} /></label>
        <div className="row-end">
          <button className="primary">{editId ? 'Save changes' : 'Add user'}</button>
          {editId && <button type="button" className="ghost" onClick={() => { setEditId(null); setForm(blank); }}>Cancel</button>}
        </div>
      </form>

      <div className="card scroll">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Specialization</th><th></th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.specialization || '-'}</td>
                <td className="actions"><button className="ghost" onClick={() => edit(u)}>Edit</button><button className="danger" onClick={() => remove(u)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Appointments({ show }) {
  const [list, setList] = useState([]);
  const [re, setRe] = useState(null);
  const load = () => api.get('/admin/appointments').then((r) => setList(r.data)).catch((e) => show(errMsg(e), 'err'));
  useEffect(() => { load(); }, []);

  const save = async (id, body) => {
    try { show((await api.patch(`/admin/appointments/${id}`, body)).data.message); setRe(null); load(); }
    catch (x) { show(errMsg(x), 'err'); }
  };

  return (
    <div className="card scroll">
      <table>
        <thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {list.map((a) => (
            <tr key={a._id}>
              <td>{a.patient?.name}</td><td>{a.doctor?.name}</td>
              {re?.id === a._id ? (
                <>
                  <td><input type="date" value={re.date} onChange={(e) => setRe({ ...re, date: e.target.value })} /></td>
                  <td><input type="time" value={re.time} onChange={(e) => setRe({ ...re, time: e.target.value })} /></td>
                  <td><StatusBadge status={a.status} /></td>
                  <td className="actions"><button className="primary" onClick={() => save(a._id, { date: re.date, time: re.time })}>Save</button><button className="ghost" onClick={() => setRe(null)}>Cancel</button></td>
                </>
              ) : (
                <>
                  <td>{a.date}</td><td>{a.time}</td><td><StatusBadge status={a.status} /></td>
                  <td className="actions">
                    <button className="ghost" onClick={() => setRe({ id: a._id, date: a.date, time: a.time })}>Reschedule</button>
                    {a.status !== 'cancelled' && <button className="danger" onClick={() => save(a._id, { status: 'cancelled' })}>Cancel</button>}
                  </td>
                </>
              )}
            </tr>
          ))}
          {!list.length && <tr><td colSpan="6" className="muted">No appointments yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function Settings({ show }) {
  const [s, setS] = useState(null);
  useEffect(() => { api.get('/settings').then((r) => setS(r.data)); }, []);
  if (!s) return <p className="muted">Loading...</p>;
  const set = (k) => (e) => setS({ ...s, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    try { show((await api.put('/admin/settings', { ...s, slotMinutes: Number(s.slotMinutes) })).data.message); } catch (x) { show(errMsg(x), 'err'); }
  };
  return (
    <form className="card grid" onSubmit={submit}>
      <label>Clinic name<input value={s.clinicName} onChange={set('clinicName')} /></label>
      <label>Opening time<input type="time" value={s.workStart} onChange={set('workStart')} /></label>
      <label>Closing time<input type="time" value={s.workEnd} onChange={set('workEnd')} /></label>
      <label>Slot length (minutes)<input type="number" min="10" max="120" value={s.slotMinutes} onChange={set('slotMinutes')} /></label>
      <div className="row-end"><button className="primary">Save settings</button></div>
    </form>
  );
}

function Chart({ title, data }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" fontSize={12} /><YAxis allowDecimals={false} fontSize={12} /><Tooltip />
          <Bar dataKey="value" fill="#0f6b66" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function Analytics() {
  const [d, setD] = useState(null);
  useEffect(() => { api.get('/admin/analytics').then((r) => setD(r.data)); }, []);
  if (!d) return <p className="muted">Loading...</p>;
  return (
    <>
      <div className="stats">
        <div className="card"><big>{d.totals.users}</big><span>Total users</span></div>
        <div className="card"><big>{d.totals.appointments}</big><span>Total appointments</span></div>
      </div>
      <div className="grid2">
        <Chart title="Appointments by status" data={d.byStatus} />
        <Chart title="Appointments per doctor" data={d.byDoctor} />
        <Chart title="Appointments per day (last 14)" data={d.byDate} />
        <Chart title="Users by role" data={d.byRole} />
      </div>
    </>
  );
}

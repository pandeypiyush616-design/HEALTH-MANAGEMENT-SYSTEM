import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import Layout, { useToast, StatusBadge } from '../components/Layout';

const TABS = ['Book Appointment', 'My Appointments', 'Medical History', 'Symptom Checker', 'Profile'];

export default function PatientDashboard() {
  const [tab, setTab] = useState(TABS[0]);
  const [show, toast] = useToast();
  const [prefDoctor, setPrefDoctor] = useState('');
  return (
    <Layout title={tab} tabs={TABS} tab={tab} setTab={setTab}>
      {toast}
      {tab === TABS[0] && <Book show={show} prefDoctor={prefDoctor} />}
      {tab === TABS[1] && <History show={show} />}
      {tab === TABS[2] && <MedicalHistory />}
      {tab === TABS[3] && <Symptoms onPick={(id) => { setPrefDoctor(id); setTab(TABS[0]); }} />}
      {tab === TABS[4] && <Profile show={show} />}
    </Layout>
  );
}

// Build time slots like 09:00, 09:30 ... from clinic settings
function makeSlots(start, end, mins) {
  const toM = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
  const out = [];
  for (let m = toM(start); m + mins <= toM(end); m += mins) out.push(`${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
  return out;
}

function Book({ show, prefDoctor }) {
  const [doctors, setDoctors] = useState([]);
  const [settings, setSettings] = useState(null);
  const [f, setF] = useState({ doctor: prefDoctor, date: '', time: '', reason: '' });
  const [booked, setBooked] = useState([]);
  const today = new Date().toISOString().slice(0, 10);

  useEffect(() => {
    api.get('/patient/doctors').then((r) => setDoctors(r.data));
    api.get('/settings').then((r) => setSettings(r.data));
  }, []);
  useEffect(() => {
    if (f.doctor && f.date) api.get('/patient/booked', { params: { doctor: f.doctor, date: f.date } }).then((r) => setBooked(r.data));
  }, [f.doctor, f.date]);

  const doc = doctors.find((d) => d._id === f.doctor);
  const slots = settings ? makeSlots(settings.workStart, settings.workEnd, settings.slotMinutes) : [];

  const submit = async (e) => {
    e.preventDefault();
    if (!f.time) return show('Please choose a time slot', 'err');
    try {
      show((await api.post('/patient/appointments', f)).data.message);
      setF({ ...f, time: '', reason: '' });
      api.get('/patient/booked', { params: { doctor: f.doctor, date: f.date } }).then((r) => setBooked(r.data));
    } catch (x) { show(errMsg(x), 'err'); }
  };

  return (
    <form className="card" onSubmit={submit}>
      <div className="grid">
        <label>Doctor
          <select required value={f.doctor} onChange={(e) => setF({ ...f, doctor: e.target.value, time: '' })}>
            <option value="">Choose a doctor</option>
            {doctors.map((d) => <option key={d._id} value={d._id}>{d.name} - {d.specialization || 'General'}</option>)}
          </select>
        </label>
        <label>Date<input type="date" required min={today} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value, time: '' })} /></label>
      </div>
      {doc?.availability?.length > 0 && <p className="muted">Usual hours: {doc.availability.join(' | ')}</p>}

      {f.doctor && f.date && (
        <>
          <p><b>Available times</b></p>
          <div className="slots">
            {slots.map((t) => {
              const past = f.date === today && t < new Date().toTimeString().slice(0, 5);
              const taken = booked.includes(t) || past;
              return <button type="button" key={t} disabled={taken} className={f.time === t ? 'slotbtn on' : 'slotbtn'} onClick={() => setF({ ...f, time: t })}>{t}</button>;
            })}
          </div>
        </>
      )}
      <label>Reason for visit<input value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder="Briefly describe your concern" /></label>
      <div className="row-end"><button className="primary">Book appointment</button></div>
    </form>
  );
}

function History({ show }) {
  const [list, setList] = useState([]);
  const [rate, setRate] = useState(null);
  const load = () => api.get('/patient/appointments').then((r) => setList(r.data));
  useEffect(() => { load(); }, []);

  const cancel = async (id) => {
    if (!confirm('Cancel this appointment?')) return;
    try { show((await api.patch(`/patient/appointments/${id}/cancel`)).data.message); load(); } catch (x) { show(errMsg(x), 'err'); }
  };
  const sendFeedback = async (e) => {
    e.preventDefault();
    try { show((await api.post('/patient/feedback', { appointment: rate.id, rating: Number(rate.rating), comment: rate.comment })).data.message); setRate(null); load(); }
    catch (x) { show(errMsg(x), 'err'); }
  };

  return (
    <>
      {rate && (
        <form className="card grid" onSubmit={sendFeedback}>
          <label>Rating
            <select value={rate.rating} onChange={(e) => setRate({ ...rate, rating: e.target.value })}>
              {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} star{n > 1 && 's'}</option>)}
            </select>
          </label>
          <label>Comment<input value={rate.comment} onChange={(e) => setRate({ ...rate, comment: e.target.value })} /></label>
          <div className="row-end"><button className="primary">Send feedback</button><button type="button" className="ghost" onClick={() => setRate(null)}>Cancel</button></div>
        </form>
      )}
      <div className="card scroll">
        <table>
          <thead><tr><th>Date</th><th>Time</th><th>Doctor</th><th>Reason</th><th>Doctor notes</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {list.map((a) => (
              <tr key={a._id}>
                <td>{a.date}</td><td>{a.time}</td><td>{a.doctor?.name}</td><td>{a.reason || '-'}</td><td>{a.notes || '-'}</td>
                <td><StatusBadge status={a.status} /></td>
                <td className="actions">
                  {['pending', 'confirmed'].includes(a.status) && <button className="danger" onClick={() => cancel(a._id)}>Cancel</button>}
                  {a.status === 'completed' && !a.feedbackGiven && <button className="ghost" onClick={() => setRate({ id: a._id, rating: 5, comment: '' })}>Rate visit</button>}
                </td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="7" className="muted">You have no appointments yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function MedicalHistory() {
  const [recs, setRecs] = useState([]);
  useEffect(() => { api.get('/patient/records').then((r) => setRecs(r.data)); }, []);
  return (
    <div className="card scroll">
      <table>
        <thead><tr><th>Date</th><th>Doctor</th><th>Diagnosis</th><th>Prescription</th><th>Notes</th></tr></thead>
        <tbody>
          {recs.map((r) => <tr key={r._id}><td>{r.createdAt.slice(0, 10)}</td><td>{r.doctor?.name}</td><td>{r.diagnosis}</td><td>{r.prescription || '-'}</td><td>{r.notes || '-'}</td></tr>)}
          {!recs.length && <tr><td colSpan="5" className="muted">No medical records yet. They appear here after a doctor adds them.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function Symptoms({ onPick }) {
  const [text, setText] = useState('');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const check = async (e) => {
    e.preventDefault(); setBusy(true); setErr(''); setRes(null);
    try { setRes((await api.post('/ai/symptoms', { symptoms: text })).data); } catch (x) { setErr(errMsg(x)); }
    setBusy(false);
  };

  return (
    <>
      <form className="card" onSubmit={check}>
        <label>Describe your symptoms
          <textarea rows="4" required value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Sore throat and mild fever for two days" />
        </label>
        <div className="row-end"><button className="primary" disabled={busy}>{busy ? 'Checking...' : 'Find the right doctor'}</button></div>
      </form>
      {err && <div className="toast err">{err}</div>}
      {res && (
        <div className={res.emergency ? 'card emergency' : 'card'}>
          {res.emergency && <h3>This may be an emergency. Seek urgent medical care now.</h3>}
          <p><b>Suggested specialist:</b> {res.specialization} <span className={`badge u-${res.urgency}`}>{res.urgency} urgency</span></p>
          <p>{res.advice}</p>
          {res.doctors?.map((d) => <button key={d._id} className="ghost" onClick={() => onPick(d._id)}>Book {d.name}</button>)}
          <p><small className="muted">{res.disclaimer}</small></p>
        </div>
      )}
    </>
  );
}

function Profile({ show }) {
  const { user } = useAuth();
  const [f, setF] = useState({ name: user.name, phone: user.phone || '', password: '' });
  const submit = async (e) => {
    e.preventDefault();
    try {
      show((await api.put('/patient/profile', f)).data.message);
      localStorage.setItem('user', JSON.stringify({ ...user, name: f.name, phone: f.phone }));
      setF({ ...f, password: '' });
    } catch (x) { show(errMsg(x), 'err'); }
  };
  return (
    <form className="card grid" onSubmit={submit}>
      <label>Name<input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
      <label>Email<input value={user.email} disabled /></label>
      <label>Phone<input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></label>
      <label>New password (optional)<input type="password" minLength={6} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
      <div className="row-end"><button className="primary">Save profile</button></div>
    </form>
  );
}

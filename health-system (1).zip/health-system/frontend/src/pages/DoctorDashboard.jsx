import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import Layout, { useToast, StatusBadge } from '../components/Layout';

const TABS = ['Schedule', 'Appointments', 'Patient Records', 'Feedback'];

export default function DoctorDashboard() {
  const [tab, setTab] = useState(TABS[0]);
  const [show, toast] = useToast();
  return (
    <Layout title={tab} tabs={TABS} tab={tab} setTab={setTab}>
      {toast}
      {tab === TABS[0] && <Schedule show={show} />}
      {tab === TABS[1] && <Appointments show={show} />}
      {tab === TABS[2] && <Records show={show} />}
      {tab === TABS[3] && <Feedback />}
    </Layout>
  );
}

function Schedule({ show }) {
  const [slots, setSlots] = useState([]);
  const [text, setText] = useState('');
  const [appts, setAppts] = useState([]);

  useEffect(() => {
    api.get('/doctor/me').then((r) => setSlots(r.data.availability || []));
    api.get('/doctor/appointments').then((r) => setAppts(r.data));
  }, []);

  const save = async (next) => {
    try { const r = await api.put('/doctor/availability', { availability: next }); setSlots(r.data.availability); show(r.data.message); }
    catch (x) { show(errMsg(x), 'err'); }
  };

  const today = new Date().toISOString().slice(0, 10);
  const upcoming = appts.filter((a) => a.date >= today && a.status !== 'cancelled');
  const byDate = upcoming.reduce((m, a) => { (m[a.date] = m[a.date] || []).push(a); return m; }, {});

  return (
    <>
      <div className="card">
        <h3>My availability</h3>
        <p className="muted">Patients see these hours when choosing a doctor.</p>
        <div className="chips">
          {slots.map((s, i) => (
            <span className="chip" key={i}>{s}<button aria-label={`Remove ${s}`} onClick={() => save(slots.filter((_, j) => j !== i))}>x</button></span>
          ))}
          {!slots.length && <span className="muted">No hours added yet.</span>}
        </div>
        <form className="inline" onSubmit={(e) => { e.preventDefault(); if (text.trim()) { save([...slots, text]); setText(''); } }}>
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Mon-Fri 09:00-13:00" />
          <button className="primary">Add hours</button>
        </form>
      </div>

      <div className="card">
        <h3>Upcoming appointments</h3>
        {Object.keys(byDate).length === 0 && <p className="muted">Nothing scheduled.</p>}
        {Object.entries(byDate).map(([date, list]) => (
          <div key={date} className="day">
            <strong>{new Date(date + 'T00:00').toDateString()}</strong>
            {list.map((a) => (
              <div key={a._id} className="slot"><b>{a.time}</b><span>{a.patient?.name}</span><span className="muted">{a.reason}</span><StatusBadge status={a.status} /></div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}

function Appointments({ show }) {
  const [list, setList] = useState([]);
  const [notes, setNotes] = useState({});
  const load = () => api.get('/doctor/appointments').then((r) => { setList(r.data); setNotes(Object.fromEntries(r.data.map((a) => [a._id, a.notes || '']))); });
  useEffect(() => { load(); }, []);

  const update = async (id, body) => {
    try { show((await api.patch(`/doctor/appointments/${id}`, body)).data.message); load(); } catch (x) { show(errMsg(x), 'err'); }
  };

  const today = new Date().toISOString().slice(0, 10);
  const upcoming = list.filter((a) => a.date >= today && !['cancelled', 'completed'].includes(a.status));
  const past = list.filter((a) => !upcoming.includes(a));

  const Table = ({ rows, title }) => (
    <div className="card scroll">
      <h3>{title}</h3>
      <table>
        <thead><tr><th>Date</th><th>Time</th><th>Patient</th><th>Reason</th><th>Notes</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {rows.map((a) => (
            <tr key={a._id}>
              <td>{a.date}</td><td>{a.time}</td><td>{a.patient?.name}</td><td>{a.reason || '-'}</td>
              <td><input value={notes[a._id] ?? ''} onChange={(e) => setNotes({ ...notes, [a._id]: e.target.value })} onBlur={() => notes[a._id] !== (a.notes || '') && update(a._id, { notes: notes[a._id] })} placeholder="Add note" /></td>
              <td><StatusBadge status={a.status} /></td>
              <td className="actions">
                {a.status === 'pending' && <button className="primary" onClick={() => update(a._id, { status: 'confirmed' })}>Confirm</button>}
                {a.status === 'confirmed' && <button className="primary" onClick={() => update(a._id, { status: 'completed' })}>Complete</button>}
                {['pending', 'confirmed'].includes(a.status) && <button className="danger" onClick={() => update(a._id, { status: 'cancelled' })}>Cancel</button>}
              </td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="7" className="muted">None.</td></tr>}
        </tbody>
      </table>
    </div>
  );

  return <><Table rows={upcoming} title="Upcoming" /><Table rows={past} title="Past and cancelled" /></>;
}

function Records({ show }) {
  const [patients, setPatients] = useState([]);
  const [pid, setPid] = useState('');
  const [records, setRecords] = useState([]);
  const [form, setForm] = useState({ diagnosis: '', prescription: '', notes: '' });
  const [summary, setSummary] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.get('/doctor/patients').then((r) => setPatients(r.data)); }, []);
  const load = (id) => api.get(`/doctor/records/${id}`).then((r) => setRecords(r.data)).catch((e) => show(errMsg(e), 'err'));
  const pick = (id) => { setPid(id); setSummary(''); id ? load(id) : setRecords([]); };

  const add = async (e) => {
    e.preventDefault();
    try { show((await api.post('/doctor/records', { ...form, patient: pid })).data.message); setForm({ diagnosis: '', prescription: '', notes: '' }); load(pid); }
    catch (x) { show(errMsg(x), 'err'); }
  };
  const edit = async (r) => {
    const diagnosis = prompt('Diagnosis', r.diagnosis); if (diagnosis === null) return;
    const prescription = prompt('Prescription', r.prescription); if (prescription === null) return;
    try { show((await api.put(`/doctor/records/${r._id}`, { diagnosis, prescription })).data.message); load(pid); } catch (x) { show(errMsg(x), 'err'); }
  };
  const ai = async () => {
    setBusy(true); setSummary('');
    try { setSummary((await api.post('/ai/summary', { patientId: pid })).data.summary); } catch (x) { show(errMsg(x), 'err'); }
    setBusy(false);
  };

  return (
    <>
      <div className="card">
        <label>Select patient
          <select value={pid} onChange={(e) => pick(e.target.value)}>
            <option value="">Choose a patient</option>
            {patients.map((p) => <option key={p._id} value={p._id}>{p.name} ({p.email})</option>)}
          </select>
        </label>
      </div>

      {pid && (
        <>
          <div className="card">
            <div className="between"><h3>AI history summary</h3><button className="ghost" disabled={busy} onClick={ai}>{busy ? 'Summarising...' : 'Summarise history'}</button></div>
            {summary && <p className="ai-box">{summary}</p>}
            {summary && <small className="muted">AI-generated. Verify against the full records before acting on it.</small>}
          </div>

          <form className="card grid" onSubmit={add}>
            <label>Diagnosis<input required value={form.diagnosis} onChange={(e) => setForm({ ...form, diagnosis: e.target.value })} /></label>
            <label>Prescription<input value={form.prescription} onChange={(e) => setForm({ ...form, prescription: e.target.value })} /></label>
            <label>Notes<input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
            <div className="row-end"><button className="primary">Save record</button></div>
          </form>

          <div className="card scroll">
            <table>
              <thead><tr><th>Date</th><th>Doctor</th><th>Diagnosis</th><th>Prescription</th><th>Notes</th><th></th></tr></thead>
              <tbody>
                {records.map((r) => (
                  <tr key={r._id}>
                    <td>{r.createdAt.slice(0, 10)}</td><td>{r.doctor?.name}</td><td>{r.diagnosis}</td><td>{r.prescription || '-'}</td><td>{r.notes || '-'}</td>
                    <td><button className="ghost" onClick={() => edit(r)}>Edit</button></td>
                  </tr>
                ))}
                {!records.length && <tr><td colSpan="6" className="muted">No records yet.</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}

function Feedback() {
  const [d, setD] = useState(null);
  useEffect(() => { api.get('/doctor/feedback').then((r) => setD(r.data)); }, []);
  if (!d) return <p className="muted">Loading...</p>;
  return (
    <>
      <div className="stats"><div className="card"><big>{d.average ?? '-'}</big><span>Average rating (out of 5)</span></div></div>
      <div className="card">
        {d.feedback.map((f) => (
          <div key={f._id} className="slot"><b>{'★'.repeat(f.rating)}{'☆'.repeat(5 - f.rating)}</b><span>{f.patient?.name}</span><span className="muted">{f.comment || 'No comment'}</span></div>
        ))}
        {!d.feedback.length && <p className="muted">No feedback yet.</p>}
      </div>
    </>
  );
}

import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import DoctorDashboard from './pages/DoctorDashboard';
import PatientDashboard from './pages/PatientDashboard';

const home = { admin: '/admin', doctor: '/doctor', patient: '/patient' };

// Redirects to login if logged out, or to the user's own dashboard if the role is wrong
function Protected({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={home[user.role]} replace />;
  return children;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/" element={<Navigate to={user ? home[user.role] : '/login'} replace />} />
      <Route path="/login" element={user ? <Navigate to={home[user.role]} replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to={home[user.role]} replace /> : <Register />} />
      <Route path="/admin" element={<Protected role="admin"><AdminDashboard /></Protected>} />
      <Route path="/doctor" element={<Protected role="doctor"><DoctorDashboard /></Protected>} />
      <Route path="/patient" element={<Protected role="patient"><PatientDashboard /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

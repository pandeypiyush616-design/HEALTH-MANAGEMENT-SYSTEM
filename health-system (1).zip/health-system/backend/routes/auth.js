const router = require('express').Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

const sign = (user) => jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const clean = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, phone: u.phone, specialization: u.specialization });

// Public registration creates PATIENTS only. Admin creates doctors/admins.
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
    if (await User.findOne({ email })) return res.status(400).json({ message: 'Email already registered' });
    const user = await User.create({ name, email, password, phone, role: 'patient' });
    res.status(201).json({ message: 'Account created successfully', token: sign(user), user: clean(user) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: (email || '').toLowerCase() });
    if (!user || !(await user.matchPassword(password || ''))) return res.status(400).json({ message: 'Wrong email or password' });
    res.json({ message: 'Login successful', token: sign(user), user: clean(user) });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/me', protect, (req, res) => res.json({ user: clean(req.user) }));

module.exports = router;

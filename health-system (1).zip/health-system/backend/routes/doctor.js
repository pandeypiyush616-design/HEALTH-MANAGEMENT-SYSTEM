const router = require('express').Router();
const Appointment = require('../models/Appointment');
const Record = require('../models/Record');
const Feedback = require('../models/Feedback');
const User = require('../models/User');
const { protect, allow } = require('../middleware/auth');

router.use(protect, allow('doctor'));

// ---------- Schedule ----------
router.get('/me', (req, res) => res.json(req.user));

router.put('/availability', async (req, res) => {
  const user = await User.findById(req.user._id);
  user.availability = (req.body.availability || []).map((s) => s.trim()).filter(Boolean);
  await user.save();
  res.json({ message: 'Schedule updated successfully', availability: user.availability });
});

// ---------- Appointments ----------
router.get('/appointments', async (req, res) => {
  res.json(await Appointment.find({ doctor: req.user._id }).populate('patient', 'name email phone').sort('date time'));
});

router.patch('/appointments/:id', async (req, res) => {
  const { status, notes } = req.body;
  const appt = await Appointment.findOne({ _id: req.params.id, doctor: req.user._id });
  if (!appt) return res.status(404).json({ message: 'Appointment not found' });
  if (status) appt.status = status;
  if (notes !== undefined) appt.notes = notes;
  await appt.save();
  res.json({ message: `Appointment ${status || 'updated'} successfully` });
});

// ---------- Patients & records ----------
router.get('/patients', async (req, res) => {
  const ids = await Appointment.distinct('patient', { doctor: req.user._id });
  res.json(await User.find({ _id: { $in: ids } }).select('name email phone'));
});

router.get('/records/:patientId', async (req, res) => {
  if (!(await Appointment.exists({ doctor: req.user._id, patient: req.params.patientId })))
    return res.status(403).json({ message: 'Not your patient' });
  res.json(await Record.find({ patient: req.params.patientId }).populate('doctor', 'name specialization').sort('-createdAt'));
});

router.post('/records', async (req, res) => {
  const { patient, diagnosis, prescription, notes } = req.body;
  if (!patient || !diagnosis) return res.status(400).json({ message: 'Patient and diagnosis are required' });
  if (!(await Appointment.exists({ doctor: req.user._id, patient })))
    return res.status(403).json({ message: 'You can only add records for your own patients' });
  await Record.create({ patient, doctor: req.user._id, diagnosis, prescription, notes });
  res.status(201).json({ message: 'Patient record saved' });
});

router.put('/records/:id', async (req, res) => {
  const rec = await Record.findOne({ _id: req.params.id, doctor: req.user._id });
  if (!rec) return res.status(404).json({ message: 'Record not found (you can only edit your own records)' });
  ['diagnosis', 'prescription', 'notes'].forEach((f) => { if (req.body[f] !== undefined) rec[f] = req.body[f]; });
  await rec.save();
  res.json({ message: 'Record updated successfully' });
});

// ---------- Feedback ----------
router.get('/feedback', async (req, res) => {
  const list = await Feedback.find({ doctor: req.user._id }).populate('patient', 'name').sort('-createdAt');
  const average = list.length ? (list.reduce((s, f) => s + f.rating, 0) / list.length).toFixed(1) : null;
  res.json({ average, feedback: list });
});

module.exports = router;

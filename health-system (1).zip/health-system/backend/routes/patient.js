const router = require('express').Router();
const User = require('../models/User');
const Appointment = require('../models/Appointment');
const Record = require('../models/Record');
const Feedback = require('../models/Feedback');
const { protect, allow } = require('../middleware/auth');

router.use(protect, allow('patient'));

router.get('/doctors', async (req, res) => {
  res.json(await User.find({ role: 'doctor' }).select('name specialization availability'));
});

// Times already taken for a doctor on a date
router.get('/booked', async (req, res) => {
  const { doctor, date } = req.query;
  const list = await Appointment.find({ doctor, date, status: { $ne: 'cancelled' } }).select('time');
  res.json(list.map((a) => a.time));
});

router.post('/appointments', async (req, res) => {
  try {
    const { doctor, date, time, reason } = req.body;
    if (!doctor || !date || !time) return res.status(400).json({ message: 'Doctor, date and time are required' });
    if (new Date(`${date}T${time}`) < new Date()) return res.status(400).json({ message: 'Please choose a future date and time' });
    const doc = await User.findOne({ _id: doctor, role: 'doctor' });
    if (!doc) return res.status(404).json({ message: 'Doctor not found' });
    if (await Appointment.findOne({ doctor, date, time, status: { $ne: 'cancelled' } }))
      return res.status(400).json({ message: 'That slot is already booked. Please pick another time' });
    const appt = await Appointment.create({ patient: req.user._id, doctor, date, time, reason });
    res.status(201).json({ message: 'Appointment booked. Waiting for doctor confirmation', appointment: appt });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.get('/appointments', async (req, res) => {
  const list = await Appointment.find({ patient: req.user._id }).populate('doctor', 'name specialization').sort('-date -time').lean();
  const fb = await Feedback.find({ patient: req.user._id }).select('appointment');
  const done = new Set(fb.map((f) => String(f.appointment)));
  res.json(list.map((a) => ({ ...a, feedbackGiven: done.has(String(a._id)) })));
});

router.patch('/appointments/:id/cancel', async (req, res) => {
  const appt = await Appointment.findOne({ _id: req.params.id, patient: req.user._id });
  if (!appt) return res.status(404).json({ message: 'Appointment not found' });
  if (['completed', 'cancelled'].includes(appt.status)) return res.status(400).json({ message: `Cannot cancel a ${appt.status} appointment` });
  appt.status = 'cancelled';
  await appt.save();
  res.json({ message: 'Appointment cancelled' });
});

router.get('/records', async (req, res) => {
  res.json(await Record.find({ patient: req.user._id }).populate('doctor', 'name specialization').sort('-createdAt'));
});

router.put('/profile', async (req, res) => {
  const { name, phone, password } = req.body;
  const user = await User.findById(req.user._id);
  if (name) user.name = name;
  if (phone !== undefined) user.phone = phone;
  if (password) {
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters' });
    user.password = password;
  }
  await user.save();
  res.json({ message: 'Profile updated successfully' });
});

router.post('/feedback', async (req, res) => {
  try {
    const { appointment, rating, comment } = req.body;
    const appt = await Appointment.findOne({ _id: appointment, patient: req.user._id, status: 'completed' });
    if (!appt) return res.status(400).json({ message: 'You can only review completed appointments' });
    await Feedback.create({ patient: req.user._id, doctor: appt.doctor, appointment, rating, comment });
    res.status(201).json({ message: 'Thank you for your feedback' });
  } catch (e) { res.status(400).json({ message: e.code === 11000 ? 'Feedback already submitted' : e.message }); }
});

module.exports = router;

const router = require('express').Router();
const User = require('../models/User');
const Appointment = require('../models/Appointment');
const Record = require('../models/Record');
const { protect, allow } = require('../middleware/auth');

// Calls the Claude API from the SERVER so the key is never exposed to the browser
async function askClaude(system, userText) {
  if (!process.env.ANTHROPIC_API_KEY) throw new Error('ANTHROPIC_API_KEY is missing in backend/.env');
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.AI_MODEL || 'claude-sonnet-5-5',
      max_tokens: 700,
      system,
      messages: [{ role: 'user', content: userText }],
    }),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message || 'AI request failed');
  return data.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
}

// Patient: symptom checker -> suggests a specialization and matching doctors
router.post('/symptoms', protect, allow('patient'), async (req, res) => {
  try {
    const { symptoms } = req.body;
    if (!symptoms || symptoms.trim().length < 5) return res.status(400).json({ message: 'Please describe your symptoms' });
    const doctors = await User.find({ role: 'doctor' }).select('name specialization');
    const specs = [...new Set(doctors.map((d) => d.specialization).filter(Boolean))];

    const system = `You are a triage assistant inside a clinic booking app. You do NOT diagnose.
Reply with ONLY valid JSON, no markdown, in this shape:
{"specialization": "<best match from: ${specs.join(', ') || 'General Physician'}>", "urgency": "low|medium|high", "advice": "<2-3 plain sentences>", "emergency": true|false}
Set emergency true and urgency high for chest pain, trouble breathing, stroke signs, heavy bleeding, or similar, and tell the person to seek emergency care now.`;

    const raw = await askClaude(system, symptoms);
    let result;
    try { result = JSON.parse(raw.replace(/```json|```/g, '').trim()); }
    catch { return res.status(502).json({ message: 'AI returned an unreadable answer. Please try again' }); }

    const suggested = doctors.filter((d) => d.specialization.toLowerCase() === String(result.specialization).toLowerCase());
    res.json({ ...result, doctors: suggested, disclaimer: 'This is not a medical diagnosis. Please consult a doctor.' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// Doctor: short summary of a patient's history
router.post('/summary', protect, allow('doctor'), async (req, res) => {
  try {
    const { patientId } = req.body;
    if (!(await Appointment.exists({ doctor: req.user._id, patient: patientId })))
      return res.status(403).json({ message: 'Not your patient' });
    const records = await Record.find({ patient: patientId }).populate('doctor', 'name').sort('createdAt');
    if (!records.length) return res.json({ summary: 'No medical records yet for this patient.' });
    const text = records.map((r) => `${r.createdAt.toISOString().slice(0, 10)} | Dr ${r.doctor?.name} | Dx: ${r.diagnosis} | Rx: ${r.prescription} | Notes: ${r.notes}`).join('\n');
    const summary = await askClaude(
      'You summarise patient history for a doctor. Be brief: key conditions, medications, and any pattern worth noticing, in under 120 words. Do not invent facts.',
      text
    );
    res.json({ summary });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;

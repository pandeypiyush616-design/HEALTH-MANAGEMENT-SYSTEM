const router = require('express').Router();
const User = require('../models/User');
const Appointment = require('../models/Appointment');
const Setting = require('../models/Setting');
const { protect, allow } = require('../middleware/auth');

router.use(protect, allow('admin'));

// ---------- User management ----------
router.get('/users', async (req, res) => {
  res.json(await User.find().select('-password').sort('-createdAt'));
});

router.post('/users', async (req, res) => {
  try {
    const { name, email, password, role, specialization, phone } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
    if (await User.findOne({ email })) return res.status(400).json({ message: 'Email already in use' });
    const user = await User.create({ name, email, password, role, specialization, phone });
    res.status(201).json({ message: 'User created successfully', user: { ...user.toObject(), password: undefined } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.put('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    ['name', 'email', 'role', 'specialization', 'phone'].forEach((f) => { if (req.body[f] !== undefined) user[f] = req.body[f]; });
    if (req.body.password) user.password = req.body.password;
    await user.save();
    res.json({ message: 'User updated successfully' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

router.delete('/users/:id', async (req, res) => {
  if (req.params.id === String(req.user._id)) return res.status(400).json({ message: 'You cannot delete your own account' });
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'User deleted successfully' });
});

// ---------- Appointment management ----------
router.get('/appointments', async (req, res) => {
  res.json(await Appointment.find().populate('patient doctor', 'name email specialization').sort('-date -time'));
});

router.patch('/appointments/:id', async (req, res) => {
  const { date, time, status } = req.body;
  const appt = await Appointment.findById(req.params.id);
  if (!appt) return res.status(404).json({ message: 'Appointment not found' });
  if (date || time) {
    const clash = await Appointment.findOne({
      _id: { $ne: appt._id }, doctor: appt.doctor, date: date || appt.date, time: time || appt.time, status: { $ne: 'cancelled' },
    });
    if (clash) return res.status(400).json({ message: 'That slot is already booked for this doctor' });
  }
  if (date) appt.date = date;
  if (time) appt.time = time;
  if (status) appt.status = status;
  await appt.save();
  res.json({ message: 'Appointment updated successfully' });
});

// ---------- System settings ----------
router.put('/settings', async (req, res) => {
  const s = await Setting.get();
  ['clinicName', 'workStart', 'workEnd', 'slotMinutes'].forEach((f) => { if (req.body[f] !== undefined) s[f] = req.body[f]; });
  await s.save();
  res.json({ message: 'Settings updated successfully', settings: s });
});

// ---------- Performance analytics ----------
router.get('/analytics', async (req, res) => {
  const [users, appts] = await Promise.all([User.find().select('role'), Appointment.find().populate('doctor', 'name')]);
  const count = (arr, keyFn) => Object.entries(arr.reduce((m, x) => { const k = keyFn(x); m[k] = (m[k] || 0) + 1; return m; }, {}));
  res.json({
    totals: { users: users.length, appointments: appts.length },
    byRole: count(users, (u) => u.role).map(([name, value]) => ({ name, value })),
    byStatus: count(appts, (a) => a.status).map(([name, value]) => ({ name, value })),
    byDoctor: count(appts, (a) => a.doctor?.name || 'Unknown').map(([name, value]) => ({ name, value })),
    byDate: count(appts, (a) => a.date).map(([name, value]) => ({ name, value })).sort((a, b) => a.name.localeCompare(b.name)).slice(-14),
  });
});

module.exports = router;

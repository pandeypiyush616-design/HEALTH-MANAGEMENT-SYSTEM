require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const Setting = require('./models/Setting');
const { protect } = require('./middleware/auth');

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/doctor', require('./routes/doctor'));
app.use('/api/patient', require('./routes/patient'));
app.use('/api/ai', require('./routes/ai'));

// Any logged-in user can read clinic settings (needed for booking slots)
app.get('/api/settings', protect, async (req, res) => res.json(await Setting.get()));
app.get('/', (req, res) => res.send('Healthcare API is running'));

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(process.env.PORT || 5000, () => console.log(`Server on port ${process.env.PORT || 5000}`));
  })
  .catch((err) => { console.error('MongoDB connection failed:', err.message); process.exit(1); });

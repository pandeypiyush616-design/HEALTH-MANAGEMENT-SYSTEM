const mongoose = require('mongoose');

module.exports = mongoose.model('Record', new mongoose.Schema({
  patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  diagnosis: { type: String, required: true },
  prescription: { type: String, default: '' },
  notes: { type: String, default: '' },
}, { timestamps: true }));

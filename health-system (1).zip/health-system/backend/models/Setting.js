const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  clinicName: { type: String, default: 'CareConnect Clinic' },
  workStart: { type: String, default: '09:00' },
  workEnd: { type: String, default: '17:00' },
  slotMinutes: { type: Number, default: 30 },
});

// There is only ever one settings document
schema.statics.get = async function () {
  return (await this.findOne()) || (await this.create({}));
};

module.exports = mongoose.model('Setting', schema);

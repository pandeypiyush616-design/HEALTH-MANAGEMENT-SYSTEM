// Run once:  npm run seed   -> creates 1 admin, 2 doctors, 1 patient for testing
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const users = [
    { name: 'Admin', email: 'admin@clinic.com', password: 'admin123', role: 'admin' },
    { name: 'Dr. Asha Verma', email: 'asha@clinic.com', password: 'doctor123', role: 'doctor', specialization: 'General Physician', availability: ['Mon-Fri 09:00-13:00'] },
    { name: 'Dr. Rohan Mehta', email: 'rohan@clinic.com', password: 'doctor123', role: 'doctor', specialization: 'Cardiologist', availability: ['Mon, Wed, Fri 14:00-17:00'] },
    { name: 'Test Patient', email: 'patient@clinic.com', password: 'patient123', role: 'patient' },
  ];
  for (const u of users) {
    if (!(await User.findOne({ email: u.email }))) { await User.create(u); console.log('Created', u.email); }
  }
  console.log('Seed done');
  process.exit(0);
})();
